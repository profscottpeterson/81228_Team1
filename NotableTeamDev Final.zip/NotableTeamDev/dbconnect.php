<?php
$connection = mysqli_connect("localhost", "rschulz", "CkfBDwB2A", "rschulz");

if (!$connection) {
    die("The connection has failed: ".mysql_connect());
}

